# Gestion de Classe — projet Android hors ligne

## Contenu
- Application Android native Java.
- Base SQLite locale : élèves, présences, notes.
- Vue de moyenne pondérée par élève.
- Écran de licence annuelle et validation RSA hors ligne (squelette à configurer).

## État du projet
Ce dépôt est un **prototype de départ**, pas un APK compilé ou testé. L'environnement qui l'a généré ne possède pas Android SDK/Gradle. Avant une utilisation en établissement, il faut compiler et tester sur de vrais téléphones, ajouter export/import chiffré, modifier/supprimer des élèves et des notes, et finaliser la génération des licences.

## Construire l'APK
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier `GestionDeClasse`.
3. Installer les composants SDK proposés par Android Studio (compile SDK 35).
4. Synchroniser Gradle, puis choisir **Build > Build APK(s)**.
5. L'APK de débogage se trouve normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

## Licence annuelle hors ligne
Le code est préparé pour une signature RSA `SHA256withRSA`. Il faut :
1. Générer une paire RSA privée/publique dans un environnement administrateur sécurisé.
2. Remplacer `PUBLIC_KEY_BASE64` dans `LicenseManager.java` par la clé publique X.509 encodée en Base64.
3. Créer un outil de génération de licences qui signe exactement le texte `AAAA-MM-JJ|DEVICE_ID`, puis formate la clé ainsi : `AAAA-MM-JJ.DEVICE_ID.SIGNATURE_BASE64URL`.
4. Garder la clé privée hors de l'application et hors du téléphone enseignant.

**Important :** tant que la clé publique de production n'est pas configurée, aucune licence de production ne doit être distribuée. Une vérification d'expiration basée sur l'horloge du téléphone peut être contournée par un utilisateur qui modifie cette horloge ; une solution plus forte doit mémoriser un état temporel protégé et être testée.

## Confidentialité
Les données scolaires sont sensibles. Le prototype désactive la sauvegarde automatique Android, mais ne chiffre pas encore la base SQLite. Ajouter chiffrement, export/import contrôlé, politique de conservation et tests de restauration avant usage réel.

## Compilation depuis un téléphone uniquement
Le dossier `.github/workflows/build-apk.yml` permet une compilation dans GitHub Actions, sans Android Studio sur le téléphone. Il faut d'abord placer le contenu du projet dans un dépôt GitHub, puis ouvrir l'onglet **Actions** et lancer **Construire APK Android**. À la fin, ouvrir l'exécution réussie et télécharger l'artefact `Gestion-de-Classe-APK`. GitHub peut demander une connexion et l'activation d'Actions.

Ce workflow produit un APK de débogage pour essai. Il ne constitue pas une version de production signée. La licence RSA n'est pas opérationnelle tant que la clé publique de production et l'outil de génération des clés n'ont pas été configurés.

## Fonctions ajoutées dans la version de travail (primaire - Burkina Faso)
- Paramètres locaux de l'école : nom de l'école, directeur/directrice et année scolaire.
- Fiche texte de carte scolaire individuelle par élève (matricule, nom, prénom, sexe, classe, école, année). La photo et l'export/impression ne sont pas encore implémentés.
- Plans d'amélioration individuelle : difficultés, objectif, activités, échéance et bilan.
- Plans d'amélioration collective : classe, discipline, difficultés communes, objectif, activités, échéance et bilan.
- Niveaux prévus : CP1, CP2, CE1, CE2, CM1 et CM2, saisis librement dans la classe de l'élève.

## Limites importantes avant une utilisation réelle
Cette archive reste un projet source et non un APK déjà compilé. Les bulletins PDF, photos de carte, sauvegarde/export des données, gestion complète des disciplines officielles et outil de création des clés annuelles sont encore à finaliser. La clé publique d'activation est un emplacement réservé et l'application ne doit pas être considérée comme prête pour un déploiement en production tant que l'activation n'est pas configurée et testée.
