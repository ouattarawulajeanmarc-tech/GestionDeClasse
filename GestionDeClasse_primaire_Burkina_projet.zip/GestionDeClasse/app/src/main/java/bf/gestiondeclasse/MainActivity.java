package bf.gestiondeclasse;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.database.Cursor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private SchoolDb db;
    private LinearLayout root, content;
    private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new SchoolDb(this);
        showHome();
    }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(12,10,12,10); return t;
    }
    private Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> r.run()); return b;
    }
    private void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,12,16,12);
        root.addView(text(title, 25));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        TextView foot = text("Gestion de Classe • Fonctionnement hors ligne", 12);
        foot.setGravity(Gravity.CENTER); root.addView(foot);
        setContentView(root);
    }
    private void showHome() {
        if (!LicenseManager.isActive(this)) { showActivation(); return; }
        setup("Gestion de Classe");
        content.addView(text("Élèves enregistrés : " + db.studentCount(), 18));
        content.addView(button("Élèves", this::showStudents));
        content.addView(button("Cartes scolaires individuelles", this::showCards));
        content.addView(button("Présences / absences", this::showAttendance));
        content.addView(button("Notes", this::showGrades));
        content.addView(button("Bulletins et moyennes", this::showReports));
        content.addView(button("Plan d’amélioration individuelle", this::showIndividualPlans));
        content.addView(button("Plan d’amélioration collective", this::showCollectivePlans));
        content.addView(button("Paramètres de l’école", this::showSchoolSettings));
        content.addView(button("Activation annuelle", this::showActivation));
        content.addView(text("Les données sont enregistrées sur ce téléphone. Export/sauvegarde à ajouter avant usage en production.", 14));
    }
    private EditText field(String hint) { EditText e = new EditText(this); e.setHint(hint); content.addView(e); return e; }
    private void showStudents() {
        setup("Gestion des élèves");
        EditText matricule = field("Matricule (facultatif)");
        EditText nom = field("Nom *"); EditText prenom = field("Prénom");
        EditText sexe = field("Sexe"); EditText classe = field("Classe");
        content.addView(button("Enregistrer l'élève", () -> {
            if (nom.getText().toString().trim().isEmpty()) { nom.setError("Le nom est obligatoire"); return; }
            db.addStudent(matricule.getText().toString().trim(), nom.getText().toString().trim(),
                prenom.getText().toString().trim(), sexe.getText().toString().trim(), classe.getText().toString().trim());
            new AlertDialog.Builder(this).setMessage("Élève enregistré sur ce téléphone.").setPositiveButton("OK",(d,w)->showStudents()).show();
        }));
        content.addView(text("Liste des élèves", 20));
        try (Cursor c = db.students()) {
            while (c.moveToNext()) content.addView(text(c.getString(2)+" "+c.getString(3)+" • "+c.getString(1)+" • "+c.getString(5), 16));
        }
        content.addView(button("Retour", this::showHome));
    }
    private void chooseStudent(String title, java.util.function.BiConsumer<Long,String> action) {
        try (Cursor c = db.students()) {
            if (c.getCount() == 0) { new AlertDialog.Builder(this).setMessage("Ajoute d'abord un élève.").setPositiveButton("OK",null).show(); return; }
            long[] ids = new long[c.getCount()]; String[] labels = new String[c.getCount()]; int i=0;
            while(c.moveToNext()){ ids[i]=c.getLong(0); labels[i]=c.getString(2)+" "+c.getString(3); i++; }
            new AlertDialog.Builder(this).setTitle(title).setItems(labels,(d,which)->action.accept(ids[which],labels[which])).show();
        }
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private void showAttendance() {
        setup("Présences et absences");
        content.addView(text("Date : "+today(), 16));
        content.addView(button("Marquer présent", () -> chooseStudent("Élève présent",(id,n)->{db.markAttendance(id,today(),"Présent"); toast(n+" : présent");})));
        content.addView(button("Marquer absent", () -> chooseStudent("Élève absent",(id,n)->{db.markAttendance(id,today(),"Absent"); toast(n+" : absent");})));
        content.addView(button("Marquer en retard", () -> chooseStudent("Élève en retard",(id,n)->{db.markAttendance(id,today(),"Retard"); toast(n+" : retard");})));
        content.addView(button("Retour", this::showHome));
    }
    private void showGrades() {
        setup("Saisie des notes");
        content.addView(button("Ajouter une note", () -> chooseStudent("Choisir l'élève",(id,n)->gradeDialog(id,n))));
        content.addView(button("Retour", this::showHome));
    }
    private void gradeDialog(long id, String student) {
        LinearLayout form = new LinearLayout(this); form.setPadding(20,0,20,0); form.setOrientation(LinearLayout.VERTICAL);
        EditText mat = new EditText(this); mat.setHint("Matière"); form.addView(mat);
        EditText eval = new EditText(this); eval.setHint("Évaluation (devoir, composition...)"); form.addView(eval);
        EditText note = new EditText(this); note.setHint("Note sur 20"); note.setInputType(8194); form.addView(note);
        EditText coef = new EditText(this); coef.setHint("Coefficient (défaut 1)"); coef.setInputType(8194); form.addView(coef);
        new AlertDialog.Builder(this).setTitle(student).setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
            try {
                double val=Double.parseDouble(note.getText().toString()); double co=coef.getText().toString().isEmpty()?1:Double.parseDouble(coef.getText().toString());
                if(val<0||val>20||co<=0) throw new IllegalArgumentException();
                db.addGrade(id,mat.getText().toString(),eval.getText().toString(),val,co,today()); toast("Note enregistrée");
            } catch(Exception ex) { toast("Note ou coefficient invalide"); }
        }).show();
    }
    private void showReports() {
        setup("Bulletins et résultats");
        content.addView(text("Moyenne pondérée par élève (sur 20)", 18));
        try (Cursor students = db.students()) {
            while(students.moveToNext()) {
                long id=students.getLong(0); String name=students.getString(2)+" "+students.getString(3);
                try (Cursor g=db.getReadableDatabase().rawQuery("SELECT SUM(note*coefficient), SUM(coefficient), COUNT(*) FROM grades WHERE student_id=?",new String[]{String.valueOf(id)})) {
                    g.moveToFirst(); String avg = g.getInt(2)==0 ? "Aucune note" : String.format(Locale.getDefault(),"%.2f / 20",g.getDouble(0)/g.getDouble(1));
                    content.addView(text(name+" : "+avg,16));
                }
            }
        }
        content.addView(text("Cette première version affiche les moyennes. La mise en page PDF/impression des bulletins reste à intégrer.",14));
        content.addView(button("Retour", this::showHome));
    }

    private void showCards() {
        setup("Cartes scolaires individuelles");
        content.addView(text("Sélectionne un élève pour afficher sa fiche de carte scolaire. La photo et l'impression/PDF seront à ajouter dans une prochaine étape.", 14));
        content.addView(button("Afficher une carte", () -> chooseStudent("Carte scolaire", (id, name) -> {
            try (Cursor c = db.getReadableDatabase().rawQuery("SELECT matricule,nom,prenom,sexe,classe FROM students WHERE id=?", new String[]{String.valueOf(id)})) {
                if (c.moveToFirst()) {
                    String school = db.getSetting("school_name"); if (school.isEmpty()) school = "Établissement à renseigner";
                    String year = db.getSetting("school_year"); if (year.isEmpty()) year = "Année scolaire à renseigner";
                    String card = "CARTE SCOLAIRE\n" + school + "\n\nNom : " + c.getString(1) + "\nPrénom(s) : " + c.getString(2) + "\nMatricule : " + c.getString(0) + "\nSexe : " + c.getString(3) + "\nClasse : " + c.getString(4) + "\nAnnée scolaire : " + year;
                    new AlertDialog.Builder(this).setTitle("Carte de " + name).setMessage(card).setPositiveButton("Fermer", null).show();
                }
            }
        }));
        content.addView(button("Retour", this::showHome));
    }
    private void showSchoolSettings() {
        setup("Paramètres de l’école");
        EditText school = field("Nom de l’école"); school.setText(db.getSetting("school_name"));
        EditText director = field("Nom du directeur / de la directrice"); director.setText(db.getSetting("director"));
        EditText year = field("Année scolaire (ex. 2026-2027)"); year.setText(db.getSetting("school_year"));
        content.addView(button("Enregistrer les paramètres", () -> {
            db.setSetting("school_name", school.getText().toString().trim());
            db.setSetting("director", director.getText().toString().trim());
            db.setSetting("school_year", year.getText().toString().trim());
            toast("Paramètres enregistrés sur le téléphone"); showHome();
        }));
        content.addView(button("Retour", this::showHome));
    }
    private EditText dialogField(LinearLayout box, String hint) { EditText e = new EditText(this); e.setHint(hint); box.addView(e); return e; }
    private void showIndividualPlans() {
        setup("Plans d’amélioration individuelle");
        content.addView(button("Créer un plan pour un élève", () -> chooseStudent("Choisir l’élève", (id, name) -> {
            LinearLayout box = new LinearLayout(this); box.setPadding(20,0,20,0); box.setOrientation(LinearLayout.VERTICAL);
            EditText difficulty=dialogField(box,"Difficultés constatées"); EditText objective=dialogField(box,"Objectif à atteindre");
            EditText actions=dialogField(box,"Activités de remédiation"); EditText period=dialogField(box,"Période / échéance"); EditText review=dialogField(box,"Bilan / progrès observés");
            new AlertDialog.Builder(this).setTitle("Plan : " + name).setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                db.addIndividualPlan(id,difficulty.getText().toString(),objective.getText().toString(),actions.getText().toString(),period.getText().toString(),review.getText().toString(),today()); toast("Plan individuel enregistré"); showIndividualPlans();
            }).show();
        })));
        content.addView(text("Plans enregistrés",18));
        try (Cursor c=db.individualPlans()) { while(c.moveToNext()) content.addView(text(c.getString(1)+" "+c.getString(2)+"\nDifficulté : "+c.getString(3)+"\nObjectif : "+c.getString(4)+"\nActions : "+c.getString(5)+"\nPériode : "+c.getString(6)+"\nBilan : "+c.getString(7),15)); }
        content.addView(button("Retour",this::showHome));
    }
    private void showCollectivePlans() {
        setup("Plans d’amélioration collective");
        content.addView(button("Créer un plan pour la classe", () -> {
            LinearLayout box = new LinearLayout(this); box.setPadding(20,0,20,0); box.setOrientation(LinearLayout.VERTICAL);
            EditText classe=dialogField(box,"Classe (CP1, CP2, CE1, CE2, CM1, CM2…)"); EditText discipline=dialogField(box,"Discipline");
            EditText difficulty=dialogField(box,"Difficultés communes constatées"); EditText objective=dialogField(box,"Objectif collectif");
            EditText actions=dialogField(box,"Activités prévues"); EditText period=dialogField(box,"Période / échéance"); EditText review=dialogField(box,"Bilan des résultats");
            new AlertDialog.Builder(this).setTitle("Nouveau plan collectif").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                db.addCollectivePlan(classe.getText().toString(),discipline.getText().toString(),difficulty.getText().toString(),objective.getText().toString(),actions.getText().toString(),period.getText().toString(),review.getText().toString(),today()); toast("Plan collectif enregistré"); showCollectivePlans();
            }).show();
        }));
        content.addView(text("Plans enregistrés",18));
        try (Cursor c=db.collectivePlans()) { while(c.moveToNext()) content.addView(text("Classe : "+c.getString(0)+" • Discipline : "+c.getString(1)+"\nDifficultés : "+c.getString(2)+"\nObjectif : "+c.getString(3)+"\nActions : "+c.getString(4)+"\nPériode : "+c.getString(5)+"\nBilan : "+c.getString(6),15)); }
        content.addView(button("Retour",this::showHome));
    }

    private void showActivation() {
        setup("Activation annuelle");
        content.addView(text("Identifiant de cet appareil :",16));
        TextView id = text(LicenseManager.deviceId(this),14); id.setTextIsSelectable(true); content.addView(id);
        content.addView(text("Demande une clé annuelle correspondant à cet appareil. La vérification fonctionne hors ligne.",14));
        EditText key = field("Clé d'activation");
        content.addView(button("Activer", () -> {
            if (LicenseManager.activate(this,key.getText().toString())) {
                new AlertDialog.Builder(this).setMessage("Licence activée.").setPositiveButton("OK",(d,w)->showHome()).show();
            } else toast("Clé invalide, expirée ou non liée à cet appareil. Configure d'abord la clé publique du projet.");
        }));
        content.addView(text("État : "+(LicenseManager.isActive(this)?"Activée":"Non activée"),16));
        content.addView(button("Retour",this::showHome));
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
