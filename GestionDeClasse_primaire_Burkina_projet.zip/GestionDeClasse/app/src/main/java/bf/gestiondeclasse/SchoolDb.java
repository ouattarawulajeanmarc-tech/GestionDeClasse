package bf.gestiondeclasse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SchoolDb extends SQLiteOpenHelper {
    public SchoolDb(Context c) { super(c, "gestion_classe.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, matricule TEXT, nom TEXT NOT NULL, prenom TEXT, sexe TEXT, classe TEXT)");
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, date TEXT, status TEXT, UNIQUE(student_id,date))");
        db.execSQL("CREATE TABLE grades(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, matiere TEXT, evaluation TEXT, note REAL, coefficient REAL, date TEXT)");
        db.execSQL("CREATE TABLE individual_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, difficulty TEXT, objective TEXT, actions TEXT, period TEXT, review TEXT, date TEXT)");
        db.execSQL("CREATE TABLE collective_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, classe TEXT, discipline TEXT, difficulty TEXT, objective TEXT, actions TEXT, period TEXT, review TEXT, date TEXT)");
        db.execSQL("CREATE TABLE school_settings(k TEXT PRIMARY KEY, v TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        if (oldV < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS individual_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, difficulty TEXT, objective TEXT, actions TEXT, period TEXT, review TEXT, date TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS collective_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, classe TEXT, discipline TEXT, difficulty TEXT, objective TEXT, actions TEXT, period TEXT, review TEXT, date TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS school_settings(k TEXT PRIMARY KEY, v TEXT)");
        }
    }
    public void addIndividualPlan(long studentId, String difficulty, String objective, String actions, String period, String review, String date) {
        ContentValues v = new ContentValues(); v.put("student_id", studentId); v.put("difficulty", difficulty); v.put("objective", objective); v.put("actions", actions); v.put("period", period); v.put("review", review); v.put("date", date); getWritableDatabase().insert("individual_plans", null, v);
    }
    public void addCollectivePlan(String classe, String discipline, String difficulty, String objective, String actions, String period, String review, String date) {
        ContentValues v = new ContentValues(); v.put("classe", classe); v.put("discipline", discipline); v.put("difficulty", difficulty); v.put("objective", objective); v.put("actions", actions); v.put("period", period); v.put("review", review); v.put("date", date); getWritableDatabase().insert("collective_plans", null, v);
    }
    public void setSetting(String key, String value) { ContentValues v = new ContentValues(); v.put("k", key); v.put("v", value); getWritableDatabase().insertWithOnConflict("school_settings", null, v, SQLiteDatabase.CONFLICT_REPLACE); }
    public String getSetting(String key) { try (Cursor c = getReadableDatabase().rawQuery("SELECT v FROM school_settings WHERE k=?", new String[]{key})) { return c.moveToFirst() ? c.getString(0) : ""; } }
    public Cursor individualPlans() { return getReadableDatabase().rawQuery("SELECT p.id,s.nom,s.prenom,p.difficulty,p.objective,p.actions,p.period,p.review FROM individual_plans p LEFT JOIN students s ON s.id=p.student_id ORDER BY p.id DESC", null); }
    public Cursor collectivePlans() { return getReadableDatabase().rawQuery("SELECT classe,discipline,difficulty,objective,actions,period,review FROM collective_plans ORDER BY id DESC", null); }
    public long addStudent(String matricule, String nom, String prenom, String sexe, String classe) {
        ContentValues v = new ContentValues();
        v.put("matricule", matricule); v.put("nom", nom); v.put("prenom", prenom);
        v.put("sexe", sexe); v.put("classe", classe);
        return getWritableDatabase().insert("students", null, v);
    }
    public Cursor students() {
        return getReadableDatabase().rawQuery("SELECT id, matricule, nom, prenom, sexe, classe FROM students ORDER BY nom, prenom", null);
    }
    public int studentCount() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM students", null)) { c.moveToFirst(); return c.getInt(0); }
    }
    public void markAttendance(long studentId, String date, String status) {
        ContentValues v = new ContentValues();
        v.put("student_id", studentId); v.put("date", date); v.put("status", status);
        getWritableDatabase().insertWithOnConflict("attendance", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void addGrade(long studentId, String subject, String evaluation, double note, double coef, String date) {
        ContentValues v = new ContentValues();
        v.put("student_id", studentId); v.put("matiere", subject); v.put("evaluation", evaluation);
        v.put("note", note); v.put("coefficient", coef); v.put("date", date);
        getWritableDatabase().insert("grades", null, v);
    }
}
