package bf.gestiondeclasse;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Locale;

/**
 * Format de clé : EXPIRATION_YYYY-MM-DD.DEVICE_ID.SIGNATURE_BASE64URL
 * La signature RSA SHA256 doit couvrir exactement : EXPIRATION_YYYY-MM-DD + "|" + DEVICE_ID.
 * IMPORTANT : remplacer PUBLIC_KEY_BASE64 par la clé publique correspondant à votre clé privée.
 * Ne jamais intégrer la clé privée dans l'application.
 */
public final class LicenseManager {
    // Clé publique de démonstration (à remplacer avant toute distribution).
    private static final String PUBLIC_KEY_BASE64 = "REPLACE_WITH_YOUR_X509_RSA_PUBLIC_KEY_BASE64";
    private LicenseManager() {}

    public static String deviceId(Context c) {
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        return id == null ? "unknown-device" : id.toLowerCase(Locale.ROOT);
    }

    public static boolean activate(Context c, String license) {
        try {
            String[] parts = license.trim().split("\\.");
            if (parts.length != 3) return false;
            String expiry = parts[0], device = parts[1], sig = parts[2];
            if (!device.equals(deviceId(c))) return false;
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
            sdf.setLenient(false);
            java.util.Date exp = sdf.parse(expiry);
            if (exp == null || System.currentTimeMillis() > exp.getTime() + 86399999L) return false;
            byte[] pub = Base64.decode(PUBLIC_KEY_BASE64, Base64.DEFAULT);
            java.security.PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(pub));
            Signature verifier = Signature.getInstance("SHA256withRSA");
            verifier.initVerify(publicKey);
            verifier.update((expiry + "|" + device).getBytes(StandardCharsets.UTF_8));
            byte[] signature = Base64.decode(sig, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            if (!verifier.verify(signature)) return false;
            SharedPreferences p = c.getSharedPreferences("license", Context.MODE_PRIVATE);
            return p.edit().putString("expiry", expiry).putString("device", device).putString("license", license).commit();
        } catch (Exception e) { return false; }
    }

    public static boolean isActive(Context c) {
        SharedPreferences p = c.getSharedPreferences("license", Context.MODE_PRIVATE);
        String expiry = p.getString("expiry", null), device = p.getString("device", null);
        if (expiry == null || device == null || !device.equals(deviceId(c))) return false;
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
            sdf.setLenient(false);
            java.util.Date d = sdf.parse(expiry);
            return d != null && System.currentTimeMillis() <= d.getTime() + 86399999L;
        } catch (Exception e) { return false; }
    }
}
